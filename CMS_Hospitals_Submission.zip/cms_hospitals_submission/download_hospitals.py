#!/usr/bin/env python3
"""Download changed CMS Hospitals CSVs concurrently. Python 3.9+, stdlib only."""
import argparse
import concurrent.futures
import csv
import hashlib
import io
import json
import logging
import os
from pathlib import Path
import re
import tempfile
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

API = 'https://data.cms.gov/provider-data/api/1/metastore/schemas/dataset/items'
LOG = logging.getLogger('cms')


def now():
    return datetime.now(timezone.utc).isoformat()


def snake_case(value):
    # Remove apostrophes rather than separating them: Patients' -> patients.
    value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode()
    value = re.sub(r"['’]", '', value)
    value = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1_\2', value)
    value = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', value)
    return re.sub(r'[^a-z0-9]+', '_', value.lower()).strip('_') or 'column'


def headers_unique(headers):
    used, result = set(), []
    for header in headers:
        base = snake_case(header)
        candidate, suffix = base, 2
        while candidate in used:
            candidate = f'{base}_{suffix}'
            suffix += 1
        used.add(candidate)
        result.append(candidate)
    return result


def open_url(url, timeout):
    request = urllib.request.Request(url, headers={'User-Agent': 'CMS-Hospitals-Downloader/1.0'})
    return urllib.request.urlopen(request, timeout=timeout)


def retry(operation, attempts):
    for attempt in range(attempts):
        try:
            return operation()
        except (OSError, ValueError, csv.Error) as exc:
            if isinstance(exc, urllib.error.HTTPError) and exc.code not in (408, 429, 500, 502, 503, 504):
                raise
            if attempt + 1 == attempts:
                raise
            time.sleep(min(2 ** attempt, 8))


def catalog(url, timeout, attempts):
    def fetch():
        with open_url(url, timeout) as response:
            data = json.load(response)
        if not isinstance(data, list):
            raise ValueError('Expected CMS metastore to return a JSON array')
        return data
    return retry(fetch, attempts)


def resources(datasets):
    result = []
    seen = set()
    for dataset in datasets:
        themes = dataset.get('theme', [])
        if isinstance(themes, str):
            themes = [themes]
        if not any(str(theme).strip().lower() == 'hospitals' for theme in themes):
            continue
        identifier = str(dataset['identifier'])
        count = 0
        for distribution in dataset.get('distribution', []):
            url = distribution.get('downloadURL')
            if not url:
                continue
            media = str(distribution.get('mediaType', '')).split(';')[0].lower()
            if media not in ('text/csv', 'application/csv') and not urllib.parse.urlsplit(url).path.lower().endswith('.csv'):
                continue
            key = identifier + ':' + url
            if key in seen:
                continue
            seen.add(key)
            count += 1
            filename = Path(urllib.parse.unquote(urllib.parse.urlsplit(url).path)).name
            # URL hash prevents collisions between multiple distributions.
            name = f'{snake_case(identifier)}_{snake_case(Path(filename).stem)}_{hashlib.sha256(url.encode()).hexdigest()[:10]}.csv'
            version = {'modified': dataset.get('modified'), 'released': dataset.get('released'), 'url': url}
            result.append({'key': key, 'identifier': identifier, 'title': dataset.get('title', ''),
                           'url': url, 'version': version, 'filename': name})
        if not count:
            raise ValueError(f'Hospitals dataset {identifier} has no downloadable CSV distribution')
    if not result:
        raise ValueError('No Hospitals CSV datasets found; refusing a misleading successful run')
    return result


def atomic_json(path, data):
    fd, temporary = tempfile.mkstemp(dir=path.parent, suffix='.tmp')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as output:
            json.dump(data, output, indent=2)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def process(resource, directory, timeout, attempts):
    target = directory / resource['filename']
    def download():
        fd, temporary = tempfile.mkstemp(dir=directory, suffix='.tmp')
        try:
            with open_url(resource['url'], timeout) as response:
                http_metadata = {'etag': response.headers.get('ETag'), 'last_modified': response.headers.get('Last-Modified')}
                # Streaming keeps large files out of memory. utf-8-sig removes a BOM.
                with io.TextIOWrapper(response, encoding='utf-8-sig', newline='') as source, os.fdopen(fd, 'w', encoding='utf-8', newline='') as output:
                    fd = None
                    reader, writer = csv.reader(source, strict=True), csv.writer(output)
                    original = next(reader, None)
                    if not original:
                        raise ValueError('CSV is empty or has no header')
                    normalized = headers_unique(original)
                    writer.writerow(normalized)
                    rows = 0
                    for row in reader:
                        if not row:
                            continue
                        if len(row) != len(original):
                            raise ValueError(f'Row {reader.line_num}: expected {len(original)} fields, got {len(row)}')
                        writer.writerow(row)
                        rows += 1
                    output.flush()
                    os.fsync(output.fileno())
            os.replace(temporary, target)
            return {'version': resource['version'], 'filename': resource['filename'],
                    'identifier': resource['identifier'], 'title': resource['title'],
                    'rows': rows, 'columns': len(normalized), 'processed_at': now(), **http_metadata}
        finally:
            if fd is not None:
                os.close(fd)
            Path(temporary).unlink(missing_ok=True)
    return retry(download, attempts)


def run(args):
    root = Path(args.output).resolve()
    root.mkdir(parents=True, exist_ok=True)
    lock = root / '.run.lock'
    try:
        lock_fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        raise RuntimeError(f'Another run is active, or a stale lock exists: {lock}')
    try:
        with os.fdopen(lock_fd, 'w') as output:
            output.write(str(os.getpid()))
        state_path = root / 'state.json'
        state = json.loads(state_path.read_text(encoding='utf-8')) if state_path.exists() else {'schema_version': 1, 'files': {}}
        if state.get('schema_version') != 1 or not isinstance(state.get('files'), dict):
            raise ValueError('Invalid state file; do not silently discard change-tracking history')
        started = now()
        available = resources(catalog(args.api, args.timeout, args.attempts))
        pending = [r for r in available if args.force or state['files'].get(r['key'], {}).get('version') != r['version'] or not (root / r['filename']).is_file()]
        summary = {'started_at': started, 'datasets': len({r['identifier'] for r in available}),
                   'csv_resources': len(available), 'skipped': len(available) - len(pending),
                   'downloaded': [], 'failed': []}
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
            futures = {executor.submit(process, r, root, args.timeout, args.attempts): r for r in pending}
            for future in concurrent.futures.as_completed(futures):
                resource = futures[future]
                try:
                    record = future.result()
                except Exception as exc:
                    summary['failed'].append({'identifier': resource['identifier'], 'url': resource['url'], 'error': str(exc)})
                    LOG.error('%s failed: %s', resource['identifier'], exc)
                    continue
                state['files'][resource['key']] = record
                # Only checkpoint successful files, so partial failures retry next run.
                atomic_json(state_path, state)
                summary['downloaded'].append(record)
                LOG.info('%s: %s rows', resource['identifier'], record['rows'])
        summary['finished_at'] = now()
        summary['status'] = 'failed' if summary['failed'] else 'success'
        atomic_json(root / 'last_run.json', summary)
        if not summary['failed']:
            state['last_successful_run'] = summary['finished_at']
            atomic_json(state_path, state)
        print(json.dumps({k: (len(v) if isinstance(v, list) else v) for k, v in summary.items()}, indent=2))
        return 1 if summary['failed'] else 0
    finally:
        lock.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='hospital_data')
    parser.add_argument('--api', default=API)
    parser.add_argument('--workers', type=int, default=6)
    parser.add_argument('--timeout', type=float, default=120)
    parser.add_argument('--attempts', type=int, default=3)
    parser.add_argument('--force', action='store_true', help='Refresh every CSV, ignoring stored versions')
    args = parser.parse_args()
    if args.workers < 1 or args.attempts < 1 or args.timeout <= 0:
        parser.error('workers, attempts and timeout must be positive')
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    try:
        return run(args)
    except Exception:
        LOG.exception('Run failed')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
