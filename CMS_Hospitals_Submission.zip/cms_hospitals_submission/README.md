# CMS Hospitals downloader

Portable Python 3.9+ script for the CMS Provider Data metastore. Uses only the Python standard library; no package installation is required.

## Run

```bash
python download_hospitals.py --output hospital_data --workers 6
```

The first run downloads every CSV distribution belonging to the exact Hospitals theme. Later runs compare the dataset's modified date, released date and download URL with the last successfully processed version. Unchanged files are skipped. A missing local output is downloaded again. Use `--force` to refresh everything.

Each CSV is streamed through a worker: headers become snake_case, while data values (including leading zeros) remain strings. Duplicate normalized headers receive numbered suffixes. UTF-8 BOMs are handled. Files with invalid row widths fail instead of being silently published.

## Daily scheduling

Schedule the same command once daily. Scheduling is external to the script so it works on regular Windows and Linux machines.

Linux cron example (replace these absolute paths):

```cron
0 2 * * * /usr/bin/python3 /opt/cms/download_hospitals.py --output /opt/cms/hospital_data >> /opt/cms/job.log 2>&1
```

On Windows, create a daily task in Task Scheduler. Use the full path to python.exe as the program and these arguments, replacing paths:

```text
"C:\cms\download_hospitals.py" --output "C:\cms\hospital_data"
```

Use the same absolute output directory every day because it contains the change-tracking state. Configure the scheduler to avoid overlapping runs and monitor nonzero exit codes.

## Recovery and metadata

- state.json records each successfully processed file's metadata, row count and processing time. It is atomically replaced after each successful file.
- last_run.json records the latest download, skip and failure summary.
- Temporary CSVs are atomically promoted only after processing succeeds. Failed files retain their old checkpoint and are retried on the next run.
- HTTP timeouts, retries and bounded workers are configurable. Permanent HTTP errors are not retried.
- A lock prevents overlapping runs using the same output directory. If the process is forcibly killed, confirm no run remains active before deleting .run.lock.
- Files from datasets removed from the catalog are retained rather than automatically deleted.
- Incremental detection relies on CMS updating catalog metadata or URLs. HTTP ETag and Last-Modified are recorded for diagnostics but are not independently polled. Use --force if a source changes without a metadata update.
- An interruption after CSV promotion but before state persistence may cause one harmless repeat download.

## Validation and sample

```bash
python -m unittest -v test_download_hospitals.py
```

Local integration tests verify header conversion, header collisions, preserved leading zeros, first-run loading, unchanged-run skipping, changed-file detection, and failure recovery without advancing the failed file's checkpoint.

sample_output.csv is actual processed CMS data from dataset wue8-3vwe (Ambulatory Surgical Center Quality Measures - National). This source currently contains one data row. sample_provenance.json identifies the source and successful processing metadata. The live metastore returned 75 Hospitals datasets during preparation. A complete download of all 75 datasets has not been executed as part of this validation.

CMS endpoint:
https://data.cms.gov/provider-data/api/1/metastore/schemas/dataset/items
