"""Local integration tests; no external network required."""
import argparse
import contextlib
import http.server
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
import download_hospitals as job


class PipelineTests(unittest.TestCase):
    def test_headers(self):
        self.assertEqual(job.snake_case("Patients' rating of the facility linear mean score"), 'patients_rating_of_the_facility_linear_mean_score')
        self.assertEqual(job.headers_unique(['A B', 'A-B', 'A B 2', '']), ['a_b', 'a_b_2', 'a_b_2_2', 'column'])

    def test_incremental_failure_recovery(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            class Handler(http.server.SimpleHTTPRequestHandler):
                def __init__(self, *args, **kwargs):
                    super().__init__(*args, directory=str(root), **kwargs)
                def log_message(self, *args):
                    pass
            server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                base = f'http://127.0.0.1:{server.server_port}'
                def dataset(identifier, modified, filename, theme='Hospitals'):
                    return {'identifier': identifier, 'theme': [theme], 'modified': modified,
                            'distribution': [{'downloadURL': base + '/' + filename, 'mediaType': 'text/csv'}]}
                records = [dataset('one', '2026-01-01', 'one.csv'), dataset('two', '2026-01-01', 'two.csv'), dataset('ignored', '2026-01-01', 'missing.csv', 'Other')]
                def save_catalog():
                    (root / 'catalog.json').write_text(json.dumps(records))
                save_catalog()
                (root / 'one.csv').write_text('\ufeffFacility ID,Patients\' rating\n00123,4\n', encoding='utf-8')
                (root / 'two.csv').write_text('A B,A-B\nx,y\n')
                args = argparse.Namespace(output=str(root / 'out'), api=base + '/catalog.json', timeout=5, attempts=1, workers=2, force=False)
                with contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(job.run(args), 0)
                    summary = json.loads((root / 'out/last_run.json').read_text())
                    self.assertEqual(len(summary['downloaded']), 2)
                    output = next((root / 'out').glob('one_*.csv')).read_text()
                    self.assertIn('facility_id,patients_rating', output)
                    self.assertIn('00123,4', output)
                    self.assertEqual(job.run(args), 0)
                    self.assertEqual(json.loads((root / 'out/last_run.json').read_text())['skipped'], 2)
                    records[1]['modified'] = '2026-02-01'
                    save_catalog()
                    (root / 'two.csv').write_text('A B,A-B\nx,y,z\n')
                    self.assertEqual(job.run(args), 1)
                    state = json.loads((root / 'out/state.json').read_text())
                    self.assertEqual(state['files']['two:' + base + '/two.csv']['version']['modified'], '2026-01-01')
                    (root / 'two.csv').write_text('A B,A-B\nx,y\n')
                    self.assertEqual(job.run(args), 0)
                    summary = json.loads((root / 'out/last_run.json').read_text())
                    self.assertEqual(summary['skipped'], 1)
                    self.assertEqual(len(summary['downloaded']), 1)
            finally:
                server.shutdown()
                server.server_close()
                thread.join()


if __name__ == '__main__':
    unittest.main()
